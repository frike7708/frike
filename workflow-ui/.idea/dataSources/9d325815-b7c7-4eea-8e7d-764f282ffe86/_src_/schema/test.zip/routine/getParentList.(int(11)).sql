CREATE FUNCTION getParentList(rootId INT)
  RETURNS VARCHAR(1000)
  BEGIN
DECLARE sParentList varchar(1000);
DECLARE sParentTemp varchar(1000);
SET sParentTemp =cast(rootId as CHAR);
WHILE sParentTemp is not null DO
IF (sParentList is not null) THEN
SET sParentList = concat(sParentTemp,',',sParentList);
ELSE
SET sParentList = concat(sParentTemp);
END IF;
SELECT group_concat(parent_id) INTO sParentTemp FROM s_hidden_type where FIND_IN_SET(id,sParentTemp)>0;
END WHILE;
RETURN sParentList;
END;
